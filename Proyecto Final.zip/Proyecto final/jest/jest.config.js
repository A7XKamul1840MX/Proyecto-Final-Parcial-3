// jest.config.js
module.exports = {
    testEnvironment: 'jsdom', // Necesario para las pruebas en un entorno basado en el navegador
};