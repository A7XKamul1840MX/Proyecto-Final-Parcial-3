const { isValidName, updateWordList, processInput } = require('../src/Prueba1');

test('isValidName should return true for valid names', () => {
    expect(isValidName('John Doe')).toBeTruthy();
    expect(isValidName('Alice')).toBeTruthy();
});
