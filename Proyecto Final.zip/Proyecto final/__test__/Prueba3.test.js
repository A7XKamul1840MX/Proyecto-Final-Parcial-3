const { isValidName, updateWordList, processInput } = require('../src/Prueba3');

test('isValidName should return false for invalid names', () => {
    expect(isValidName('!"#$%&&/')).toBeFalsy();
    expect(isValidName('12345')).toBeFalsy();
});