const { isValidName, updateWordList, processInput } = require('../src/Prueba2');

test('isValidName should return false for invalid names', () => {
    expect(isValidName('123')).toBeFalsy();
    expect(isValidName('John123')).toBeFalsy();
});

