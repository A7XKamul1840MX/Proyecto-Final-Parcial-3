const lastWords = [];

function isValidName(name) {
    return /^[a-zA-Z\s]*$/.test(name);
}

function updateWordList() {
    wordList.innerHTML = '';
    lastWords.forEach(word => {
        const listItem = document.createElement('li');
        listItem.textContent = word;
        wordList.appendChild(listItem);
    });
}

function processInput() {
    const text = inputText.value.trim().toUpperCase();

    if (isValidName(text) && lastWords.length < 3) {
        if (!lastWords.includes(text)) {
            outputText.textContent = text;
            lastWords.push(text);
            updateWordList();
        } else {
            alert('El nombre ya está en la lista');
        }
    } else {
        alert('Ingresa un nombre válido (solo letras y espacios) o has alcanzado el límite de nombres');
    }
}

module.exports = {
    isValidName,
    updateWordList,
    processInput,
};
