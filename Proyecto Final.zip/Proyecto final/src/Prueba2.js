const lastWords = [];

function isValidName(name) {
    return /^[a-zA-Z\s]*$/.test(name);
}

function updateWordList(words) {
    const wordList = words.map(word => ({ text: word }));
    return wordList;
}

function processInput(text) {
    text = text.trim().toUpperCase();

    if (isValidName(text) && lastWords.length < 3) {
        if (!lastWords.includes(text)) {
            lastWords.push(text);
            updateWordList(lastWords);
            return text;
        } else {
            return 'El nombre ya está en la lista';
        }
    } else {
        return 'Ingresa un nombre válido (solo letras y espacios) o has alcanzado el límite de nombres';
    }
}

module.exports = {
    isValidName,
    updateWordList,
    processInput,
};
